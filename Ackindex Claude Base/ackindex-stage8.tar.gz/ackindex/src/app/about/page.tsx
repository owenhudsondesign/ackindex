import PageLayout from '@/components/PageLayout';
import Container from '@/components/Container';
import Image from 'next/image';

export default function AboutPage() {
  return (
    <PageLayout>
      <Container className="py-16">
        {/* Hero Section */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-ack-black mb-6">
            About AckIndex
          </h1>
          <p className="text-lg text-ack-dark-gray leading-relaxed">
            Making Nantucket&apos;s civic data accessible and understandable through AI-powered analysis.
          </p>
        </div>

        {/* Placeholder Banner Image */}
        <div className="mb-12 rounded-xl overflow-hidden bg-ack-light-gray">
          <div className="aspect-[21/9] flex items-center justify-center">
            <div className="text-center">
              <svg
                className="w-16 h-16 mx-auto mb-4 text-ack-dark-gray"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.5"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <p className="text-ack-dark-gray text-sm">Banner Image Placeholder</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-3xl mx-auto prose prose-lg">
          <h2 className="text-2xl font-bold text-ack-black mb-4">Our Mission</h2>
          <p className="text-ack-dark-gray mb-6 leading-relaxed">
            AckIndex is an independent civic technology project dedicated to making Nantucket&apos;s 
            government data more accessible to residents. We believe that informed citizens make 
            better decisions, and transparency is the foundation of good governance.
          </p>

          <h2 className="text-2xl font-bold text-ack-black mb-4">How It Works</h2>
          <p className="text-ack-dark-gray mb-6 leading-relaxed">
            Our platform uses artificial intelligence to analyze and index public documents from 
            town meetings, planning boards, and other civic sources. When you ask a question, 
            AckIndex searches through this indexed data and provides answers with direct citations 
            to the source documents.
          </p>

          <h2 className="text-2xl font-bold text-ack-black mb-4">Transparency & Accuracy</h2>
          <p className="text-ack-dark-gray mb-6 leading-relaxed">
            We&apos;re committed to accuracy and transparency. Every answer includes citations to 
            the original source documents, so you can verify the information yourself. If we 
            don&apos;t have enough information to answer your question, we&apos;ll tell you that too.
          </p>

          <h2 className="text-2xl font-bold text-ack-black mb-4">Get Involved</h2>
          <p className="text-ack-dark-gray leading-relaxed">
            AckIndex is a community project. If you have suggestions for improvement, additional 
            data sources we should include, or would like to contribute to the project, please 
            reach out via our contact page.
          </p>
        </div>
      </Container>
    </PageLayout>
  );
}

